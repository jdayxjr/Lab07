<?php

/*
 * Author: Louie Zhu
 * Date: Jan 22, 2016
 * File: index.php
 * Description: site homepage; redirect to list_movie.php
 * 
 */

header("Location: list_movie.php");