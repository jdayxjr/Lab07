<?php

/*
 * Author: your name
 * Date: today's date
 * File: index.php
 * Description: site homepage; redirect users to list_movie.php
 * 
 */

header("Location: list_movie.php");