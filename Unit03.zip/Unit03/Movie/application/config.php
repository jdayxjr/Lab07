<?php

/*
 * Author: your name
 * Date: today's date
 * File: config.php
 * Description: set application settings
 * 
 */

//local time zone
date_default_timezone_set('America/New_York');

//base url of the application
define("BASE_URL", "http://localhost/I211/Unit3/Movie");

//default path for movie images
define("MOVIE_IMG", "www/img/movies/");